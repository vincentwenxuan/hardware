#!/bin/sh

parts=( trt_pintack_small trt_pintack_large trt_pinpeg_small trt_pinpeg_large trt_pintack_hole_negative_small trt_pintack_hole_negative_large trt_pinpeg_hole_negative_small trt_pinpeg_hole_negative_large trt_logo_pintack trt_arm_upper trt_arm_lower trt_hand trt_antenna_side_bottom trt_antenna_side_top )

for part in "${parts[@]}"
do
  mkdir -p ./stl
	echo Building $part...
	openscad -s ./stl/$part.stl -D "trt_part=\"$part\"" toy_robot_toolkit.scad
done
